# OpenCV
Based on the udemy course "Introduction to Computer Vision | Master OpenCV in Python" by Rajeev Ratan


OpenCV stands for Open Source Computer Vision   (written in C++)
OpenCV 3.X is similar to OpenCV 2.X except the removal of certain patented algorithms such as SIFT and SURF
